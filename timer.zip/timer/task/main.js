import {E} from './app.js';

 function RUN(){
    let start=document.querySelector('.start');
   
    start.addEventListener('click',E); 
}
RUN();